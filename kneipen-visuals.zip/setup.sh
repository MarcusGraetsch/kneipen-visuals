#!/usr/bin/env bash
set -e

echo "========================================================"
echo "  Kneipen-Visuals: Automatische Einrichtung startet..."
echo "========================================================"
echo ""
echo "Hinweis: Falls nach deinem Passwort gefragt wird, tippe es"
echo "einfach blind ein (es erscheinen keine Sternchen) und drücke Enter."
echo ""

# 1. System aktualisieren & benötigte Programme installieren
echo "[1/5] Installiere Visual-Software (projectM, Audio-Tool, Maus-Ausblender)..."
sudo apt-get update -qq
sudo apt-get install -y projectm-pulseaudio pavucontrol unclutter unzip

# 2. Preset-Ordner einrichten und Dateien entpacken/kopieren
echo "[2/5] Richte Effekt-Vorlagen (Presets) ein..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="$HOME/.projectM"
PRESET_DIR="$TARGET_DIR/presets"

mkdir -p "$PRESET_DIR"

# Standard-Presets vom System übernehmen (falls vorhanden)
if [ -d "/usr/share/projectM/presets" ]; then
    cp -rn /usr/share/projectM/presets/* "$PRESET_DIR/" 2>/dev/null || true
fi

# Eigene Presets aus dem mitgelieferten Ordner kopieren
if [ -d "$SCRIPT_DIR/presets" ]; then
    cp -f "$SCRIPT_DIR/presets/"* "$PRESET_DIR/" 2>/dev/null || true
fi

# Falls zusätzlich eine presets.zip im Downloads- oder Skript-Ordner liegt, ebenfalls entpacken
for zfile in "$SCRIPT_DIR/presets.zip" "$HOME/Downloads/presets.zip"; do
    if [ -f "$zfile" ]; then
        echo "      Entpacke zusätzliche Presets aus $zfile..."
        unzip -oq "$zfile" -d "$PRESET_DIR/"
    fi
done

# 3. projectM Konfiguration schreiben
echo "[3/5] Konfiguriere projectM für Vollbild & Musik-Reaktion..."
cat > "$TARGET_DIR/config.inp" <<EOF
Window Width = 1280
Window Height = 720
Fullscreen = false
Mesh X = 48
Mesh Y = 36
FPS = 60
Texture Size = 1024
Preset Path = $PRESET_DIR
Title Font = /usr/share/fonts/truetype/dejavu/DejaVuSans.ttf
Menu Font = /usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf
Smooth Preset Duration = 5
Preset Duration = 25
Hard Cut Enabled = true
Hard Cut Duration = 20
Hard Cut Sensitivity = 1.5
Beat Sensitivity = 1.2
Aspect Correction = true
Shuffle Enabled = true
Soft Cut Ratings Enabled = false
EOF

# 4. Bildschirmschoner & Energiesparmodus ausschalten (damit das Bild nicht ausgeht)
echo "[4/5] Deaktiviere automatische Bildschirmsperre..."
if command -v gsettings >/dev/null 2>&1; then
    gsettings set org.gnome.desktop.session idle-delay 0 2>/dev/null || true
    gsettings set org.gnome.desktop.screensaver lock-enabled false 2>/dev/null || true
fi

# 5. Start-Symbol auf dem Desktop anlegen
echo "[5/5] Erstelle Start-Symbol auf dem Desktop..."
STARTER_CONTENT="[Desktop Entry]
Version=1.0
Type=Application
Name=Kneipen-Visuals starten
Comment=Musik-Visuals für den Beamer starten
Exec=bash -c 'unclutter -idle 2 & pavucontrol & projectM-pulseaudio'
Icon=multimedia-player
Terminal=false
Categories=AudioVideo;
"

for desk in "$HOME/Desktop" "$HOME/Schreibtisch"; do
    if [ -d "$desk" ]; then
        DESKTOP_FILE="$desk/Kneipen-Visuals.desktop"
        echo "$STARTER_CONTENT" > "$DESKTOP_FILE"
        chmod +x "$DESKTOP_FILE"
        if command -v gio >/dev/null 2>&1; then
            gio set "$DESKTOP_FILE" metadata::trusted true 2>/dev/null || true
        fi
    fi
done

echo ""
echo "========================================================"
echo "  FERTIG! Alles wurde erfolgreich eingerichtet."
echo "========================================================"
echo ""
echo "So startest du die Show:"
echo "  1. Beamer per HDMI anschließen."
echo "  2. Auf dem Desktop auf 'Kneipen-Visuals starten' doppelklicken"
echo "     (oder im Terminal 'projectM-pulseaudio' eingeben)."
echo "  3. Fenster auf den Beamer ziehen und Taste 'F' drücken (Vollbild)."
echo ""
